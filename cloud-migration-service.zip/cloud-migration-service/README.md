# Cloud Migration Service

SSH-first WordPress migration helper for the Node worker in this repository.

## Install

Upload the `cloud-migration-service` folder to `wp-content/plugins/` on both the source and destination WordPress sites, then activate **Cloud Migration Service**.

## What The Plugin Does Now

- Exposes a source export API for the Node worker.
- Displays a copied worker key that includes the site's URL and auth key.
- Creates a database artifact and file index for direct chunked streaming.
- Streams files directly from source to destination without building a full site archive.
- Exposes a backup-only API that prepares the same stream and uploads multipart TAR parts directly to CortexWP R2.
- Bundles many small files into transient stream batches and uses resumable range chunks for large files.
- Provides WP-CLI commands for fast destination imports.
- Keeps a small admin page for the worker key, exclusions, and job visibility.

This plugin no longer handles destination migration over WordPress REST or plugin-to-plugin transfer.

## Worker Setup

1. Install and activate the plugin on both sites.
2. Copy each site's worker key from **Tools > Cloud Migration**.
3. Start the Node worker from `migration-worker`.
4. Point the worker at the source site and the destination server over SSH.

## WP-CLI Commands

Import from an archive already on disk:

```bash
wp cmsvc import /path/to/archive.wpress --source-url=https://source.example.com
```

## Performance Notes

- Source exports prefer `mysqldump` when available.
- Destination imports prefer the native `mysql` client plus `wp search-replace`.
- Exclusion rules help avoid wasting time on caches, backups, and temporary files.
- The Node worker acts as an SSH/API coordinator, not as an archive relay.
- File transfer uses bundled small-file batches plus resumable large-file chunks; the database artifact is transferred after site files and then imported by the existing destination pipeline.
- The worker can use the agent API to update the source plugin from the configured plugin ZIP when `PLUGIN_VERSION` requires it.
- Backup jobs use the same queue/indexing path as migrations, but WordPress writes temporary TAR parts and uploads them directly to R2 using presigned multipart URLs from the Node worker. R2 shows one final `site-backup.tar` object per backup.

The backup/restore worker can stream its job steps and failures to Axiom by setting
`AXIOM_TOKEN`, `AXIOM_DATASET`, and optionally `AXIOM_DOMAIN` or `AXIOM_INGEST_URL` in
`migration-worker/.env`. Migration jobs are intentionally excluded from Axiom logging.
