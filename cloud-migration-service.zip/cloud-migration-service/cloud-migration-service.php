<?php
/**
 * Temporary Cloud Migration Service import shield.
 */
if ( ! defined( 'ABSPATH' ) || ! defined( 'WP_CONTENT_DIR' ) ) {
	return;
}

$cmsvc_import_shield_flag = WP_CONTENT_DIR . '/cmsvc-import-shield.json';
$cmsvc_import_shield_data = null;
$cmsvc_import_shield_read = static function () use ( $cmsvc_import_shield_flag, &$cmsvc_import_shield_data ) {
	if ( is_array( $cmsvc_import_shield_data ) ) {
		return $cmsvc_import_shield_data;
	}
	if ( ! is_readable( $cmsvc_import_shield_flag ) ) {
		$cmsvc_import_shield_data = array();
		return $cmsvc_import_shield_data;
	}
	$decoded = json_decode( (string) file_get_contents( $cmsvc_import_shield_flag ), true );
	if ( ! is_array( $decoded ) || empty( $decoded['active'] ) || (int) ( $decoded['expires'] ?? 0 ) < time() ) {
		$cmsvc_import_shield_data = array();
		return $cmsvc_import_shield_data;
	}
	$cmsvc_import_shield_data = $decoded;
	return $cmsvc_import_shield_data;
};

$cmsvc_import_shield_data = $cmsvc_import_shield_read();
$cmsvc_import_shield_is_cli = defined( 'WP_CLI' ) && WP_CLI;
if ( ! $cmsvc_import_shield_is_cli && ! empty( $cmsvc_import_shield_data['block_frontend'] ) ) {
	$uri_parts = array(
		isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '',
		isset( $_SERVER['REDIRECT_URL'] ) ? (string) $_SERVER['REDIRECT_URL'] : '',
		isset( $_SERVER['HTTP_X_ORIGINAL_URI'] ) ? (string) $_SERVER['HTTP_X_ORIGINAL_URI'] : '',
		isset( $_SERVER['HTTP_X_REWRITE_URL'] ) ? (string) $_SERVER['HTTP_X_REWRITE_URL'] : '',
		isset( $_SERVER['UNENCODED_URL'] ) ? (string) $_SERVER['UNENCODED_URL'] : '',
		isset( $_SERVER['PATH_INFO'] ) ? (string) $_SERVER['PATH_INFO'] : '',
		isset( $_SERVER['ORIG_PATH_INFO'] ) ? (string) $_SERVER['ORIG_PATH_INFO'] : '',
		isset( $_SERVER['QUERY_STRING'] ) ? (string) $_SERVER['QUERY_STRING'] : '',
		isset( $_GET['rest_route'] ) ? (string) $_GET['rest_route'] : '',
	);
	$uri_probe = rawurldecode( implode( "\n", $uri_parts ) );
	$is_rest_request = false !== strpos( $uri_probe, '/wp-json/' )
		|| false !== strpos( $uri_probe, 'rest_route=/' )
		|| 0 === strpos( $uri_probe, '/cmsvc/v1' )
		|| false !== strpos( $uri_probe, '/cmsvc/v1' );
	if ( ! $is_rest_request ) {
		http_response_code( 503 );
		if ( ! headers_sent() ) {
			header( 'Retry-After: 30' );
			header( 'Cache-Control: no-store' );
			header( 'Content-Type: text/plain; charset=UTF-8' );
		}
		echo 'Restore in progress. ' . $uri_probe;
		exit;
	}
}

add_filter(
	'pre_option_active_plugins',
	static function ( $pre ) use ( $cmsvc_import_shield_read ) {
		$data   = $cmsvc_import_shield_read();
		$plugin = isset( $data['plugin'] ) ? (string) $data['plugin'] : '';
		return '' === $plugin ? $pre : array( $plugin );
	},
	1
);

add_filter(
	'pre_site_option_active_sitewide_plugins',
	static function ( $pre ) use ( $cmsvc_import_shield_read ) {
		$data = $cmsvc_import_shield_read();
		return empty( $data ) ? $pre : array();
	},
	1
);

add_filter(
	'pre_option_template',
	static function ( $pre ) use ( $cmsvc_import_shield_read ) {
		$data = $cmsvc_import_shield_read();
		return empty( $data['template'] ) ? $pre : (string) $data['template'];
	},
	1
);

add_filter(
	'pre_option_stylesheet',
	static function ( $pre ) use ( $cmsvc_import_shield_read ) {
		$data = $cmsvc_import_shield_read();
		return empty( $data['stylesheet'] ) ? $pre : (string) $data['stylesheet'];
	},
	1
);